package com.prime.saju.sensi

object SensiCalculator {
  fun generate(profile: DeviceProfile, fingers: Int = 2): SensitivityResult {
    val baseGeneral = 95

    val hzAdj = when {
      profile.refreshRateHz >= 120f -> -6
      profile.refreshRateHz >= 90f -> -3
      else -> 0
    }

    val dpiAdj = when {
      profile.densityDpi < 400 -> +4
      profile.densityDpi > 500 -> -2
      else -> 0
    }

    val sizeAdj = when {
      profile.screenInches < 6.3 -> -2
      profile.screenInches > 6.7 -> +2
      else -> 0
    }

    val fingerAdj = when {
      fingers >= 4 -> -2
      fingers == 3 -> -1
      else -> 0
    }

    val general = clamp(baseGeneral + hzAdj + dpiAdj + sizeAdj + fingerAdj, 70, 100)
    val redDot = clamp(general - 8, 0, 100)
    val scope2x = clamp(general - 18, 0, 100)
    val scope4x = clamp(general - 28, 0, 100)
    val awm = clamp(general - 45, 0, 100)
    val freeLook = 60

    val suggestedDpi = when {
      profile.densityDpi < 400 -> 450
      profile.densityDpi in 400..520 -> 500
      else -> 520
    }

    return SensitivityResult(general, redDot, scope2x, scope4x, awm, freeLook, suggestedDpi)
  }

  private fun clamp(v: Int, min: Int, max: Int): Int = v.coerceIn(min, max)
}
