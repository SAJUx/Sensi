package com.prime.saju.sensi

import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

  private fun intOrZero(et: EditText): Int =
    et.text?.toString()?.trim()?.toIntOrNull() ?: 0

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_main)

    val phoneNameEt = findViewById<EditText>(R.id.phoneNameEt)
    val ramEt = findViewById<EditText>(R.id.ramEt)
    val romEt = findViewById<EditText>(R.id.romEt)

    val generateBtn = findViewById<TextView>(R.id.generateBtn)
    val resultTv = findViewById<TextView>(R.id.resultTv)
    val tipsTv = findViewById<TextView>(R.id.tipsTv)

    generateBtn.setOnClickListener {
      val phoneName = phoneNameEt.text?.toString()?.trim().orEmpty()
      val ram = intOrZero(ramEt)
      val rom = intOrZero(romEt)

      val detected = DeviceDetector.detect(this)
      val result = AdvancedSensiCalculator.generate(detected, ramGb = ram, romGb = rom)

      val deviceName = if (phoneName.isNotBlank()) phoneName else "${detected.manufacturer} ${detected.model}"

      resultTv.text = buildString {
        append("DEVICE: ").append(deviceName).append("\n")
        append("RAM: ").append(ram).append("GB | ROM: ").append(rom).append("GB\n\n")

        append("SENSI OUTPUT\n")
        append("General: ").append(result.general).append("\n")
        append("Red Dot: ").append(result.redDot).append("\n")
        append("2x: ").append(result.scope2x).append("\n")
        append("4x: ").append(result.scope4x).append("\n")
        append("AWM: ").append(result.awm).append("\n")
        append("Free Look: ").append(result.freeLook).append("\n")
        append("\nSuggested DPI (manual): ").append(result.suggestedDpi).append("\n\n")

        append("Detected (auto):\n")
        append("• Resolution: ").append(detected.widthPx).append(" x ").append(detected.heightPx).append("\n")
        append("• DPI: ").append(detected.densityDpi).append("\n")
        append("• Hz: ").append(String.format("%.0f", detected.refreshRateHz)).append("\n")
        append("• Screen: ").append(String.format("%.2f", detected.screenInches)).append(" inch\n")
      }

      tipsTv.text =
        "Tips:\n" +
        "• Apply these values manually inside Free Fire settings.\n" +
        "• If head overshoots: General -3 to -5.\n" +
        "• If drag slow: General +3 to +5.\n"
    }
  }
}
