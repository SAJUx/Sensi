package com.prime.saju.sensi

import android.app.Activity
import android.os.Build
import android.util.DisplayMetrics
import kotlin.math.pow
import kotlin.math.sqrt

object DeviceDetector {
  fun detect(activity: Activity): DeviceProfile {
    val display = activity.display
    val metrics = DisplayMetrics()
    display?.getRealMetrics(metrics)

    val width = metrics.widthPixels
    val height = metrics.heightPixels
    val dpi = metrics.densityDpi
    val hz = display?.refreshRate ?: 60f

    val xInches = width.toDouble() / metrics.xdpi.toDouble()
    val yInches = height.toDouble() / metrics.ydpi.toDouble()
    val inches = sqrt(xInches.pow(2.0) + yInches.pow(2.0))

    return DeviceProfile(
      manufacturer = Build.MANUFACTURER ?: "Unknown",
      model = Build.MODEL ?: "Unknown",
      androidVersion = Build.VERSION.RELEASE ?: "Unknown",
      widthPx = width,
      heightPx = height,
      densityDpi = dpi,
      refreshRateHz = hz,
      screenInches = inches
    )
  }
}
