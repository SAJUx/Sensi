package com.prime.saju.sensi

data class SensitivityResult(
  val general: Int,
  val redDot: Int,
  val scope2x: Int,
  val scope4x: Int,
  val awm: Int,
  val freeLook: Int,
  val suggestedDpi: Int
)
