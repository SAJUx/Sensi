package com.prime.saju.sensi

data class DeviceProfile(
  val manufacturer: String,
  val model: String,
  val androidVersion: String,
  val widthPx: Int,
  val heightPx: Int,
  val densityDpi: Int,
  val refreshRateHz: Float,
  val screenInches: Double
)
