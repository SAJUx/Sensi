package com.prime.saju.sensi

object AdvancedSensiCalculator {
  fun generate(detected: DeviceProfile, ramGb: Int, romGb: Int): SensitivityResult {
    val base = SensiCalculator.generate(detected, fingers = 2)

    val perfAdj = when {
      ramGb >= 12 -> -3
      ramGb >= 8 -> -2
      ramGb >= 6 -> -1
      ramGb in 4..5 -> 0
      ramGb in 2..3 -> +2
      else -> +3
    }

    val storageAdj = when {
      romGb >= 256 -> -1
      romGb >= 128 -> 0
      romGb >= 64 -> +1
      else -> +2
    }

    val general = clamp(base.general + perfAdj + storageAdj, 65, 100)
    val redDot = clamp(general - 8, 0, 100)
    val scope2x = clamp(general - 18, 0, 100)
    val scope4x = clamp(general - 28, 0, 100)
    val awm = clamp(general - 45, 0, 100)
    val freeLook = 60

    return SensitivityResult(general, redDot, scope2x, scope4x, awm, freeLook, base.suggestedDpi)
  }

  private fun clamp(v: Int, min: Int, max: Int): Int = v.coerceIn(min, max)
}
