Wrapper JAR is not included.
CI workflow builds using installed Gradle (no wrapper needed).
