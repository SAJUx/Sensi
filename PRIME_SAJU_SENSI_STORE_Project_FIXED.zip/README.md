# PRIME SAJU SENSI STORE (Android)

Hacker vibe UI + phone info input (Phone name, RAM, ROM) + auto sensitivity suggestion.

✅ This app only suggests sensitivity/DPI. It does NOT modify Free Fire or any game automatically.

## GitHub build (recommended)
Workflow:
- `.github/workflows/android-unzip-build.yml`

It unzips `PRIME_SAJU_SENSI_STORE_Project.zip` into `extracted/`, builds a debug APK, then uploads it as an artifact.

## Package
`com.prime.saju.sensi`
