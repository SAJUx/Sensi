package com.error.girlai.overlay

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.graphics.drawable.AnimationDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.error.girlai.R
import com.error.girlai.net.OpenAIClient
import com.error.girlai.store.KeyStore
import com.error.girlai.store.MemoryStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class OverlayService : Service() {

    companion object {
        const val ACTION_START = "ACTION_START_OVERLAY"
        const val ACTION_STOP = "ACTION_STOP_OVERLAY"
        private const val CHANNEL_ID = "overlay_channel"
        private const val NOTIF_ID = 1001
    }

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var params: WindowManager.LayoutParams? = null

    private val handler = Handler(Looper.getMainLooper())
    private var monitorRunning = false

    private var tts: TextToSpeech? = null
    private var speech: SpeechRecognizer? = null

    private val scope = CoroutineScope(Dispatchers.Main)

    private enum class ListeningMode { PASSIVE, COMMAND }
    private var mode: ListeningMode = ListeningMode.PASSIVE
    private var isListening = false
    private var unlockReceiver: BroadcastReceiver? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this) {
            val engine = tts ?: return@TextToSpeech
            engine.language = Locale("bn", "BD")

            // Try to pick a Bangla voice that sounds more natural/female (device dependent)
            try {
                val voices = engine.voices ?: emptySet()
                val bnVoices = voices.filter { v ->
                    val loc = v.locale
                    loc.language.equals("bn", true) && (loc.country.equals("BD", true) || loc.country.equals("IN", true))
                }
                val preferred = bnVoices.firstOrNull { v ->
                    v.name.contains("female", true) ||
                    v.name.contains("natural", true) ||
                    v.name.contains("wavenet", true)
                } ?: bnVoices.firstOrNull()
                if (preferred != null) engine.voice = preferred
            } catch (_: Throwable) { }

            engine.setPitch(1.15f)
            engine.setSpeechRate(1.0f)
        }
        speech = SpeechRecognizer.createSpeechRecognizer(this)

        unlockReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent?.action == Intent.ACTION_USER_PRESENT) {
                    tts?.speak("Sir, আমি আয়রা। আপনার জন্য কী করতে পারি?", TextToSpeech.QUEUE_FLUSH, null, "unlock")
                }
            }
        }
        try {
            registerReceiver(unlockReceiver, IntentFilter(Intent.ACTION_USER_PRESENT))
        } catch (_: Throwable) { }

    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startOverlay()
            ACTION_STOP -> stopOverlay()
            else -> startOverlay()
        }
        return START_STICKY
    }

    private fun stopListeningInternal() {
        try { speech?.stopListening() } catch (_: Throwable) { }
        try { speech?.cancel() } catch (_: Throwable) { }
        isListening = false
    }

    private fun startOverlay() {
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())

        if (monitorRunning) return
        monitorRunning = true
        handler.post(monitorRunnable)
        Toast.makeText(this, "Home-only animated avatar ✅", Toast.LENGTH_SHORT).show()
    }

    private val monitorRunnable = object : Runnable {
        override fun run() {
            val onHome = isOnHomeScreen()
            if (onHome) {
                if (overlayView == null) showOverlayInternal()
            } else {
                if (overlayView != null) hideOverlayInternal()
            }
            if (monitorRunning) handler.postDelayed(this, 900)
        }
    }

    private fun showOverlayInternal() {
        if (overlayView != null) return

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val inflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        overlayView = inflater.inflate(R.layout.overlay_avatar, null)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 80
            y = 200
        }

        val avatar = overlayView!!.findViewById<ImageView>(R.id.avatarImage)

        // Frame animation (PNG)
        avatar.setBackgroundResource(R.drawable.avatar_anim)
        (avatar.background as? AnimationDrawable)?.start()

        avatar.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f
            private var lastTap = 0L

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                val p = params ?: return false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = p.x
                        initialY = p.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        p.x = initialX + (event.rawX - initialTouchX).toInt()
                        p.y = initialY + (event.rawY - initialTouchY).toInt()
                        windowManager?.updateViewLayout(overlayView, p)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        val dx = kotlin.math.abs(event.rawX - initialTouchX)
                        val dy = kotlin.math.abs(event.rawY - initialTouchY)
                        val now = System.currentTimeMillis()
                        if (dx < 15 && dy < 15 && now - lastTap > 450) {
                            lastTap = now
                            startCommandListening()
                        }
                        return true
                    }
                }
                return false
            }
        })

        windowManager?.addView(overlayView, params)
        startPassiveListening()
    }

    private fun hideOverlayInternal() {
        overlayView?.let { windowManager?.removeView(it) }
        overlayView = null
    }

    private fun stopOverlay() {
        monitorRunning = false
        handler.removeCallbacks(monitorRunnable)
        hideOverlayInternal()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopOverlay()
        speech?.destroy()
        tts?.shutdown()
        try { unlockReceiver?.let { unregisterReceiver(it) } } catch (_: Throwable) { }
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Overlay Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Ayra AI")
            .setContentText("Home-only animated avatar is running")
            .setOngoing(true)
            .build()
    }

    private fun getDefaultHomePackage(): String? {
        val intent = Intent(Intent.ACTION_MAIN)
        intent.addCategory(Intent.CATEGORY_HOME)
        val resolveInfo = packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
        return resolveInfo?.activityInfo?.packageName
    }

    private fun isOnHomeScreen(): Boolean {
        val homePkg = getDefaultHomePackage() ?: return false

        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        val begin = end - 10_000

        val events = usm.queryEvents(begin, end)
        val event = UsageEvents.Event()
        var lastPkg: String? = null

        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                lastPkg = event.packageName
            }
        }

        return (lastPkg == null) || (lastPkg == homePkg)
    }

    private fun startPassiveListening() {
        if (isListening) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return

        mode = ListeningMode.PASSIVE
        isListening = true

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)

            // Faster end-of-speech (device dependent)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 700)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 650)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 450)

            // Prefer offline if available (often faster)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }

        fun isWake(text: String): Boolean {
            return text.contains("Ayra", ignoreCase = true) ||
                    text.contains("আয়রা") || text.contains("আইরা") || text.contains("এরা")
        }

        speech?.setRecognitionListener(AyraRecognitionListener(
            onFinal = { text ->
                isListening = false
                if (mode == ListeningMode.PASSIVE) {
                    if (isWake(text)) {
                        tts?.speak("জি স্যার, বলুন", TextToSpeech.QUEUE_FLUSH, null, "wake")
                        handler.postDelayed({ startCommandListening() }, 250)
                    } else {
                        handler.postDelayed({ startPassiveListening() }, 150)
                    }
                } else {
                    handler.postDelayed({ startPassiveListening() }, 150)
                }
            },
            onPartial = { partial ->
                if (mode == ListeningMode.PASSIVE && isWake(partial)) {
                    stopListeningInternal()
                    tts?.speak("জি স্যার, বলুন", TextToSpeech.QUEUE_FLUSH, null, "wake")
                    handler.postDelayed({ startCommandListening() }, 220)
                }
            },
            onErrorCb = {
                isListening = false
                handler.postDelayed({ startPassiveListening() }, 400)
            }
        ))

        try {
            speech?.startListening(intent)
        } catch (_: Throwable) {
            isListening = false
        }
    }

    /**
     * Command mode: one utterance -> GPT -> TTS -> back to PASSIVE
     */
    private fun startCommandListening() {
        if (isListening) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return

        mode = ListeningMode.COMMAND
        isListening = true

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)

            // Faster end-of-speech
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 850)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 700)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 500)

            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }

        speech?.setRecognitionListener(AyraRecognitionListener(
            onFinal = { userText ->
                isListening = false

                MemoryStore.append(this@OverlayService, "user", userText)

                scope.launch {
                    val apiKey = KeyStore.getApiKey(this@OverlayService)
                    if (apiKey.isBlank()) {
                        Toast.makeText(this@OverlayService, "API key সেট করুন (Main screen)", Toast.LENGTH_LONG).show()
                        tts?.speak("API কী সেট করুন", TextToSpeech.QUEUE_FLUSH, null, "nokey")
                        handler.postDelayed({ startPassiveListening() }, 400)
                        return@launch
                    }

                    val turns = MemoryStore.load(this@OverlayService).map { it.role to it.content }

                    val reply = withContext(Dispatchers.IO) {
                        OpenAIClient.respond(
                            apiKey = apiKey,
                            model = "gpt-4o-mini",
                            system = "You are Ayra, a Bengali voice assistant. Reply in Bangla, very short, fast, and helpful. Add light humor sometimes.",
                            turns = turns
                        )
                    }

                    MemoryStore.append(this@OverlayService, "assistant", reply)
                    Toast.makeText(this@OverlayService, reply, Toast.LENGTH_LONG).show()
                    tts?.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "reply")

                    handler.postDelayed({ startPassiveListening() }, 600)
                }
            },
            onPartial = { /* ignore */ },
            onErrorCb = {
                isListening = false
                handler.postDelayed({ startPassiveListening() }, 450)
            }
        ))

        try {
            speech?.startListening(intent)
        } catch (_: Throwable) {
            isListening = false
            handler.postDelayed({ startPassiveListening() }, 450)
        }
    }
}
