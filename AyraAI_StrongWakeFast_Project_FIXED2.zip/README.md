# Ayra AI (Animated + Bangla Voice + OpenAI + Memory)

- Home-only: avatar shows on launcher/home, hides inside apps
- Animated: PNG frame animation (avatar_0..avatar_5 + avatar_anim.xml)
- Tap-to-talk: tap avatar -> Bangla speech -> OpenAI -> Bangla reply (TTS)
- Memory: stores last 16 turns locally

## Notes
OpenAI advises not to expose API keys in client apps. For production, use a backend proxy.

Docs:
- Responses API: https://platform.openai.com/docs/api-reference/responses

## Wake name
Say **Ayra / আয়রা** in your speech so Ayra responds.

## Unlock greeting
When you unlock the phone, Ayra says: "Sir, আমি আয়রা। আপনার জন্য কী করতে পারি?"

## Anime character
This build uses a 12-frame original anime-style character animation (avatar_0..avatar_11).

## Wake-word (no tap)
On HOME screen, say **Ayra/আয়রা**. Ayra will reply and then listen for your command.

## Strong STT + Fast reply
Uses partial results and shorter silence timeouts for faster response (device dependent). Low voice depends on microphone + Google Speech Services.
