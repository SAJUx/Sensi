package com.prime.saju.sensi

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.StatFs
import kotlin.math.roundToInt

data class DeviceStats(
    val brand: String,
    val model: String,
    val androidVersion: String,
    val ramGb: Int,
    val storageTotalGb: Int,
    val storageFreeGb: Int
)

object DeviceStatsReader {

    fun read(context: Context): DeviceStats {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)

        val totalRamBytes = memInfo.totalMem
        val ramGb = (totalRamBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)).roundToInt().coerceAtLeast(1)

        val stat = StatFs(Environment.getDataDirectory().path)
        val totalBytes = stat.totalBytes
        val freeBytes = stat.availableBytes

        val totalGb = (totalBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)).roundToInt().coerceAtLeast(1)
        val freeGb = (freeBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)).roundToInt().coerceAtLeast(0)

        return DeviceStats(
            brand = Build.BRAND ?: "Unknown",
            model = Build.MODEL ?: "Unknown",
            androidVersion = Build.VERSION.RELEASE ?: "Unknown",
            ramGb = ramGb,
            storageTotalGb = totalGb,
            storageFreeGb = freeGb
        )
    }
}
