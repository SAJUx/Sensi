package com.prime.saju.sensi

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_main)

    val generateBtn = findViewById<TextView>(R.id.generateBtn)
    val deviceTv = findViewById<TextView>(R.id.deviceTv)
    val resultTv = findViewById<TextView>(R.id.resultTv)
    val tipsTv = findViewById<TextView>(R.id.tipsTv)

    generateBtn.setOnClickListener {
      val detected = DeviceDetector.detect(this)
      val stats = DeviceStatsReader.read(this)

      val result = AdvancedSensiCalculator.generate(
        detected = detected,
        ramGb = stats.ramGb,
        romGb = stats.storageTotalGb
      )

      deviceTv.text = buildString {
        append("Brand: ").append(stats.brand).append("\n")
        append("Model: ").append(stats.model).append("\n")
        append("Android: ").append(stats.androidVersion).append("\n\n")
        append("RAM: ").append(stats.ramGb).append(" GB\n")
        append("Storage: ").append(stats.storageTotalGb).append(" GB (Free ").append(stats.storageFreeGb).append(" GB)\n\n")
        append("Resolution: ").append(detected.widthPx).append(" x ").append(detected.heightPx).append("\n")
        append("DPI: ").append(detected.densityDpi).append("\n")
        append("Refresh: ").append(String.format("%.0f", detected.refreshRateHz)).append(" Hz\n")
        append("Screen: ").append(String.format("%.2f", detected.screenInches)).append(" inch\n")
      }

      resultTv.text = buildString {
        append("General: ").append(result.general).append("\n")
        append("Red Dot: ").append(result.redDot).append("\n")
        append("2x: ").append(result.scope2x).append("\n")
        append("4x: ").append(result.scope4x).append("\n")
        append("AWM: ").append(result.awm).append("\n")
        append("Free Look: ").append(result.freeLook).append("\n")
        append("\nSuggested DPI (manual): ").append(result.suggestedDpi)
      }

      tipsTv.text =
        "Tips:\n" +
        "• Apply these values manually inside Free Fire settings.\n" +
        "• If head overshoots: General -3 to -5.\n" +
        "• If drag slow: General +3 to +5.\n"
    }
  }
}
